<body>
<img src="getImage.php?id=1" width="175" height="200" />
</body>